var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

var ip = require('ip');
console.log("Running on IP : " + ip.address());
var request = require('request');

var currentueue = 0;
var queues = [[]];

io.on('connection', function(socket){
  console.log('a user connected');
  io.emit('HiFromMaster', 'Hi Moin');

  socket.on('GetDataToLoad', function(data){
    if(queues[currentueue].length < 1000){ // item in each queue
      queues[currentueue].push(data);
    }else{
      console.log(currentueue);
      if(currentueue < 100000){ // number of queues
        sendDataToBeInserted(queues[currentueue]);
        currentueue += 1;
      }else{
        sendDataToBeInserted(queues[currentueue]);
        currentueue = 0;
        console.log('Reset to 0');
      }
      queues[currentueue] = [];
      queues[currentueue].push(data);
    }
  });

});

function sendDataToBeInserted(array){

  console.log('Sending Data');

  var obj = {
    "data" : array
  };

  request({
    url: "http://127.0.0.1:7000/loadDataIntoDB",
    method: "POST",
    json: true,   // <--Very important!!!
    body: obj
  }, function (error, response, body){
    console.log('Data Added');
  });
}


http.listen(3000, function(){
  console.log('listening on *:3000');
});
