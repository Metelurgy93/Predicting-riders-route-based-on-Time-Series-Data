from bottle import run, get, post, request

@post('/loadData')
def loadData():
    return(request.json);





run(reLoader=True, debug=True);
