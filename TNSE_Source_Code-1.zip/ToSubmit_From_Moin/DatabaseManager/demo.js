
const MongoClient = require('mongodb').MongoClient;
const dbName = 'trafficdb';
const collectionName = 'trafficinfo';
const assert = require('assert');


MongoClient.connect('mongodb://localhost:27200', function(err, db) {
  assert.equal(null, err);
  assert.ok(db != null);

  // console.log(db.db('trafficdb').collection(collectionName));
  var ref = db.db(dbName);
  dbRef = ref.collection(collectionName);
  var from = new Date("2018-05-09T17:15:00.000Z");
  var to = new Date(from - (1 * 60 * 24)* 60000);
  console.log(from);
  console.log(to);
  console.log("--------------------------------------------------------------");

  dbRef.find({"link_id":"node_2", "source":"node_1", "time": {$gt: to, $lt:from}}).toArray(function(err, docs) {
    console.log("Connected to sharded database");
    console.log(docs.length);
    console.log(docs);
  });

});

// var endTime = new Date("2018-05-09T17:15:00.000Z");
// var startTime = new Date(endTime - (1 * 60 * 24)* 60000);
//
// console.log(endTime);
// console.log(startTime);
