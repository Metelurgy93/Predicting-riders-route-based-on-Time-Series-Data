var app = require('express')();
var http = require('http').Server(app);

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

// Connection URL
const url = 'mongodb://localhost:27000';
const dbName = 'trafficdb';
const collectionName = 'trafficinfo';

var dbRef = null;

// MongoClient.connect('mongodb://localhost:57040,localhost:57041,localhost:57042?replicaSet=conf', function(err, db) {


MongoClient.connect('mongodb://localhost:27200', function(err, db) {
  assert.equal(null, err);
  assert.ok(db != null);

  // console.log(db.db('trafficdb').collection(collectionName));

  var ref = db.db(dbName);

  dbRef = ref.collection(collectionName);

  dbRef.find({}).toArray(function(err, docs) {
    console.log("Connected to sharded database");
    // console.log(docs);
  });

});




app.post('/loadDataIntoDB', function(req, resp){

  var objects = req.body.data;
  for(var i=0;i<objects.length;i++){
    var newDate = new Date(objects[i].time)
    objects[i].time = newDate
  }

  dbRef.insertMany(objects, function(err, res) {
    if (err){
      resp.send("Error inserting data : \n" + err);
    }else{
      // console.log("Number of documents inserted: " + res.insertedCount);
      resp.send(res.insertedCount + " Documents Inserted");
    }
  });

})

app.post('/getDataForLinkID', function(req, resp){
  var source = req.body.source;
  var destination = req.body.destination;
  var duration = parseInt(req.body.duration);
  var endTime = new Date(req.body.time);
  var startTime = new Date(endTime - (duration * 60 * 24)* 60000);

  var query = {"link_id":destination, "source":source, "time": {$gt: startTime, $lt:endTime}}

  console.log(startTime);

  dbRef.find(query).toArray(function(err, docs) {
    for(var i=0;i<docs.length;i++){
      docs.time = docs[i].time.toLocaleString()
    }
    var returnObj = {
      data : docs
    };
    // console.log("Connected to sharded database");
    // console.log(docs);
    resp.send(returnObj);
    // console.log(docs.length);
  });


});

app.post('/getObjectsByLinkID', function(req,resp){
  var linkID = req.body.linkID;
  var query = { "link_id": linkID };
  dbRef.find(query).toArray(function(err, result) {
    if (err) throw err;
    resp.send(result);
  });
})

app.post('/checkConnection',function(req,resp){
  resp.send(req.body);
  console.log(req.body);
})




http.listen(7000, function(){
  console.log('listening on *:7000');
});
